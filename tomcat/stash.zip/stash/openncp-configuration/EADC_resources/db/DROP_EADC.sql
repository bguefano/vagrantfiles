DROP TABLE IF EXISTS eTransactionData;
DROP TABLE IF EXISTS eTransaction;